libnmap.plugins.s3.NmapS3Plugin
===============================

Using libnmap.plugins.s3
------------------------

This modules enables the user to directly use S3 buckets to store and retrieve NmapReports.

NmapS3Plugin methods
--------------------

.. automodule:: libnmap.plugins.s3
.. autoclass:: NmapS3Plugin
    :members:
